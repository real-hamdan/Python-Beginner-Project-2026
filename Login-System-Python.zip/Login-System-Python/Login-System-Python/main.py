import json
import os
import hashlib
import secrets
from getpass import getpass

DATA_FILE = "users.json"
MAX_ATTEMPTS = 3


def hash_password(password, salt=None):
    """Create a salted PBKDF2-SHA256 password hash."""
    if salt is None:
        salt = secrets.token_hex(16)
    digest = hashlib.pbkdf2_hmac(
        "sha256", password.encode("utf-8"), bytes.fromhex(salt), 200_000
    ).hex()
    return salt, digest


def load_users():
    if not os.path.exists(DATA_FILE):
        return {}
    try:
        with open(DATA_FILE, "r", encoding="utf-8") as file:
            data = json.load(file)
        return data if isinstance(data, dict) else {}
    except (json.JSONDecodeError, OSError):
        print("Warning: Could not read users.json.")
        return {}


def save_users(users):
    with open(DATA_FILE, "w", encoding="utf-8") as file:
        json.dump(users, file, indent=4)


def verify_password(password, salt, saved_hash):
    _, entered_hash = hash_password(password, salt)
    return secrets.compare_digest(entered_hash, saved_hash)


def register_user(users):
    print("\n--- Create Account ---")
    username = input("Choose a username: ").strip()
    if not username:
        print("Username cannot be empty.")
        return
    if username in users:
        print("That username already exists.")
        return

    password = input("Choose a password (at least 8 characters): ")
    if len(password) < 8:
        print("Password must be at least 8 characters.")
        return
    if password != input("Re-enter password: "):
        print("Passwords do not match.")
        return

    salt, digest = hash_password(password)
    users[username] = {"salt": salt, "password_hash": digest}
    save_users(users)
    print("Account created successfully!")


def login_user(users):
    print("\n--- Login ---")
    username = input("Username: ").strip()
    if username not in users:
        print("Invalid username or password.")
        return

    for attempt in range(1, MAX_ATTEMPTS + 1):
        password = ( "Password: ")
        record = users[username]
        if verify_password(password, record["salt"], record["password_hash"]):
            print(f"Welcome, {username}! Login successful.")
            return
        remaining = MAX_ATTEMPTS - attempt
        if remaining:
            print(f"Incorrect password. Attempts remaining: {remaining}")

    print("Too many failed attempts. Please try again later.")


def main():
    users = load_users()
    while True:
        print("\n==============================")
        print("      PYTHON LOGIN SYSTEM")
        print("==============================")
        print("1. Create account")
        print("2. Login")
        print("3. Exit")
        choice = input("Choose an option (1-3): ").strip()

        if choice == "1":
            register_user(users)
        elif choice == "2":
            login_user(users)
        elif choice == "3":
            print("Goodbye!")
            break
        else:
            print("Invalid choice. Please enter 1, 2, or 3.")


if __name__ == "__main__":
    main()
