# Python Login System

A beginner-friendly console login system built with Python. Users can create an account and log in with a username and password.

## Features
- Create accounts and reject duplicate usernames
- Confirm passwords during registration
- Save account records in a local JSON file
- Store salted PBKDF2-HMAC-SHA256 password hashes, not plain-text passwords
- Limit each login to three password attempts
- Uses Python's standard library only

## Requirements
- Python 3.8 or newer
- No external packages required

## How to Run
1. Download or clone this repository.
2. Open a terminal in the project folder.
3. Run `python main.py` (on some Windows systems, use `py main.py`).
4. Choose `1` to create an account, `2` to log in, or `3` to exit.

## Project Structure
```text
Login-System-Python/
├── main.py
├── README.md
├── .gitignore
├── requirements.txt
└── LICENSE
```
`users.json` is created automatically after you register an account and is excluded from Git by `.gitignore`.

## How It Works
During registration, the program generates a random salt and derives a password hash. It saves the salt and hash in `users.json`, not the original password. During login, the entered password is hashed using the saved salt and compared with the saved hash.

## Security Notes
This is an educational project, not a production-ready authentication service. Do not use a real or reused password. The local JSON file is not encrypted, and the program does not provide account recovery, multi-factor authentication, or protection against every attack. Use a trusted authentication framework and secure storage for real applications.

## Learning Goals
- Python functions, loops, and input validation
- JSON file handling
- Password hashing and salts
- Basic authentication concepts

## License
MIT
