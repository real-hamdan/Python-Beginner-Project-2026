# Password Strength Checker

A beginner-friendly Python command-line project that checks basic password characteristics and suggests improvements.

## Features
- Checks for at least 8 characters
- Checks lowercase letters, uppercase letters, numbers, and symbols
- Shows a simple result and suggestions
- Does not save the entered password

## Requirements
- Python 3.8 or newer
- No extra libraries required

## How to run
1. Open a terminal in the project folder.
2. Run `python main.py` (or `python3 main.py` on some systems).

## Important privacy note
For practice, enter only a sample password. Never type a real password used for email, banking, social media, or any other account. This tool provides only a basic educational estimate and does not prove that a password is secure.

## Skills practiced
- Python functions and strings
- Loops and conditions
- Character checks
- Basic cybersecurity awareness

## Author
Hamdan
