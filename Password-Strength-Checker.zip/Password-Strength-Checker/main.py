import string


def check_password(password):
    """Check basic password characteristics and return tips."""
    tips = []
    score = 0

    if len(password) >= 8:
        score += 1
    else:
        tips.append("Use at least 8 characters.")

    if any(c.islower() for c in password):
        score += 1
    else:
        tips.append("Add a lowercase letter (a-z).")

    if any(c.isupper() for c in password):
        score += 1
    else:
        tips.append("Add an uppercase letter (A-Z).")

    if any(c.isdigit() for c in password):
        score += 1
    else:
        tips.append("Add a number (0-9).")

    if any(c in string.punctuation for c in password):
        score += 1
    else:
        tips.append("Add a symbol, such as !, @, or #.")

    if score <= 2:
        strength = "Needs improvement"
    elif score <= 4:
        strength = "Moderate"
    else:
        strength = "Strong by these basic checks"

    return strength, tips


def main():
    print("=" * 38)
    print("      PASSWORD STRENGTH CHECKER")
    print("=" * 38)
    print("This tool checks basic password characteristics.")
    print("For privacy, your password is not saved.")

    password = input("\nEnter a SAMPLE password to check: ")
    if not password:
        print("No password entered.")
        return

    strength, tips = check_password(password)
    print(f"\nBasic strength result: {strength}")

    if tips:
        print("\nSuggestions:")
        for tip in tips:
            print(f"- {tip}")
    else:
        print("\nIt meets all five basic checks.")

    print("\nSecurity note:")
    print("- Never enter a real password used for any account.")
    print("- This is a beginner learning tool, not a full security audit.")
    print("- Longer, unique passwords or passphrases are generally safer.")


if __name__ == "__main__":
    main()
