import json
from datetime import datetime
from pathlib import Path

DATA_FILE = Path("expenses.json")


def load_expenses():
    """Load saved expenses from the JSON file."""
    if not DATA_FILE.exists():
        return []

    try:
        with DATA_FILE.open("r", encoding="utf-8") as file:
            data = json.load(file)
        return data if isinstance(data, list) else []
    except (json.JSONDecodeError, OSError):
        print("Warning: Could not read saved expenses. Starting with an empty list.")
        return []


def save_expenses(expenses):
    """Save expenses to the JSON file."""
    with DATA_FILE.open("w", encoding="utf-8") as file:
        json.dump(expenses, file, indent=4)


def add_expense(expenses):
    name = input("Expense name (e.g., Bus fare): ").strip()
    if not name:
        print("Expense name cannot be empty.")
        return

    try:
        amount = float(input("Amount (PKR): ").strip())
        if amount <= 0:
            print("Amount must be greater than zero.")
            return
    except ValueError:
        print("Please enter a valid number for the amount.")
        return

    category = input("Category (e.g., Food, Travel, Study): ").strip() or "Other"
    date = datetime.now().strftime("%Y-%m-%d")

    expenses.append({
        "name": name,
        "amount": round(amount, 2),
        "category": category,
        "date": date
    })
    save_expenses(expenses)
    print("Expense added and saved successfully!")


def view_expenses(expenses):
    if not expenses:
        print("\nNo expenses recorded yet.")
        return

    print("\n--- Your Expenses ---")
    print(f"{'No.':<5}{'Date':<13}{'Name':<22}{'Category':<16}{'Amount (PKR)':>14}")
    print("-" * 70)

    for index, expense in enumerate(expenses, start=1):
        print(
            f"{index:<5}"
            f"{expense.get('date', 'N/A'):<13}"
            f"{expense.get('name', 'Unknown')[:20]:<22}"
            f"{expense.get('category', 'Other')[:14]:<16}"
            f"{expense.get('amount', 0):>14.2f}"
        )

    print("-" * 70)
    total = sum(float(item.get("amount", 0)) for item in expenses)
    print(f"Total expenses: PKR {total:.2f}")


def show_summary(expenses):
    total = sum(float(item.get("amount", 0)) for item in expenses)
    print("\n--- Expense Summary ---")
    print(f"Number of expenses: {len(expenses)}")
    print(f"Total spent: PKR {total:.2f}")

    if expenses:
        largest = max(expenses, key=lambda item: float(item.get("amount", 0)))
        print(f"Largest expense: {largest.get('name', 'Unknown')} "
              f"(PKR {float(largest.get('amount', 0)):.2f})")


def main():
    expenses = load_expenses()

    while True:
        print("\n====== EXPENSE TRACKER ======")
        print("1. Add an expense")
        print("2. View all expenses")
        print("3. View summary")
        print("4. Exit")

        choice = input("Choose an option (1-4): ").strip()

        if choice == "1":
            add_expense(expenses)
        elif choice == "2":
            view_expenses(expenses)
        elif choice == "3":
            show_summary(expenses)
        elif choice == "4":
            print("Goodbye! Your expenses are saved in expenses.json.")
            break
        else:
            print("Invalid choice. Please enter 1, 2, 3, or 4.")


if __name__ == "__main__":
    main()
