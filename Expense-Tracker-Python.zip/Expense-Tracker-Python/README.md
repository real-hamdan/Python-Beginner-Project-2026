# Python Expense Tracker

A beginner-friendly command-line expense tracker written in Python. It lets you record daily expenses, view saved records, and calculate your total spending.

## Features
- Add an expense with a name, amount, and category
- Automatically records the current date
- View all expenses in a table
- Calculate total spending and find the largest expense
- Saves records in `expenses.json`, so they remain available after the program closes
- Handles invalid amounts and menu choices

## Requirements
- Python 3.8 or newer
- No extra libraries are required

## How to run
1. Download or clone this repository.
2. Open a terminal in the project folder.
3. Run:

   ```bash
   python main.py
   ```

   On some systems, use `python3 main.py`.

## Data storage
The program creates `expenses.json` in the same folder when you add your first expense. Keep this file if you want to preserve your records.

## Example
```text
====== EXPENSE TRACKER ======
1. Add an expense
2. View all expenses
3. View summary
4. Exit
Choose an option (1-4): 1
Expense name (e.g., Bus fare): Bus fare
Amount (PKR): 100
Category (e.g., Food, Travel, Study): Travel
Expense added and saved successfully!
```

## Skills practiced
- Variables and data types
- Lists and dictionaries
- Functions
- Loops and conditions
- File handling with JSON
- Input validation

## Author
Hamdan
