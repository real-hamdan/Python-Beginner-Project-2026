// Student Management System (C++) - purane compilers ke liye bhi chalta hai

#include <iostream>
#include <fstream>
#include <string>
#include <algorithm>
using namespace std;

struct Student {
    int roll;
    string name;
    float marks;
    Student* next;
};

Student* head = NULL;
const string FILE_NAME = "students.txt";

int readInt(const string& msg) {
    int x;
    cout << msg;
    while (!(cin >> x)) {
        cin.clear();
        cin.ignore(1000, '\n');
        cout << "Galat input. Dobara number likhein: ";
    }
    cin.ignore(1000, '\n');
    return x;
}

float readFloat(const string& msg) {
    float x;
    cout << msg;
    while (!(cin >> x)) {
        cin.clear();
        cin.ignore(1000, '\n');
        cout << "Galat input. Dobara number likhein: ";
    }
    cin.ignore(1000, '\n');
    return x;
}

Student* findStudent(int roll) {
    Student* cur = head;
    while (cur != NULL) {
        if (cur->roll == roll) return cur;
        cur = cur->next;
    }
    return NULL;
}

void appendStudent(int roll, const string& name, float marks) {
    Student* node = new Student;
    node->roll = roll;
    node->name = name;
    node->marks = marks;
    node->next = NULL;

    if (head == NULL) {
        head = node;
        return;
    }
    Student* cur = head;
    while (cur->next != NULL) cur = cur->next;
    cur->next = node;
}

void addStudent() {
    int roll = readInt("Roll number: ");
    if (findStudent(roll) != NULL) {
        cout << "Ye roll number pehle se maujood hai.\n";
        return;
    }
    string name;
    cout << "Naam: ";
    getline(cin, name);
    float marks = readFloat("Marks: ");
    appendStudent(roll, name, marks);
    cout << "Student add ho gaya.\n";
}

void displayAll() {
    if (head == NULL) {
        cout << "Koi record nahi hai.\n";
        return;
    }
    cout << "\nRoll\tMarks\tNaam\n";
    cout << "-----------------------------\n";
    for (Student* cur = head; cur != NULL; cur = cur->next)
        cout << cur->roll << "\t" << cur->marks << "\t" << cur->name << "\n";
}

void searchStudent() {
    int roll = readInt("Search karne ke liye roll number: ");
    Student* s = findStudent(roll);
    if (s == NULL)
        cout << "Student nahi mila.\n";
    else
        cout << "Mil gaya -> Roll: " << s->roll << ", Naam: " << s->name
             << ", Marks: " << s->marks << "\n";
}

void updateMarks() {
    int roll = readInt("Roll number: ");
    Student* s = findStudent(roll);
    if (s == NULL) {
        cout << "Student nahi mila.\n";
        return;
    }
    s->marks = readFloat("Naye marks: ");
    cout << "Marks update ho gaye.\n";
}

void deleteStudent() {
    int roll = readInt("Delete karne ke liye roll number: ");
    Student* cur = head;
    Student* prev = NULL;
    while (cur != NULL && cur->roll != roll) {
        prev = cur;
        cur = cur->next;
    }
    if (cur == NULL) {
        cout << "Student nahi mila.\n";
        return;
    }
    if (prev == NULL) head = cur->next;
    else prev->next = cur->next;
    delete cur;
    cout << "Student delete ho gaya.\n";
}

void sortByMarks() {
    if (head == NULL || head->next == NULL) return;
    bool swapped;
    do {
        swapped = false;
        for (Student* cur = head; cur->next != NULL; cur = cur->next) {
            if (cur->marks < cur->next->marks) {
                swap(cur->roll, cur->next->roll);
                swap(cur->name, cur->next->name);
                swap(cur->marks, cur->next->marks);
                swapped = true;
            }
        }
    } while (swapped);
    cout << "Marks ke hisab se sort ho gaya (zyada se kam).\n";
}

void saveToFile() {
    ofstream out(FILE_NAME.c_str());
    for (Student* cur = head; cur != NULL; cur = cur->next)
        out << cur->roll << " " << cur->marks << " " << cur->name << "\n";
}

void loadFromFile() {
    ifstream in(FILE_NAME.c_str());
    if (!in) return;
    int roll;
    float marks;
    string name;
    while (in >> roll >> marks) {
        in.ignore(1);
        getline(in, name);
        appendStudent(roll, name, marks);
    }
}

void freeList() {
    while (head != NULL) {
        Student* tmp = head;
        head = head->next;
        delete tmp;
    }
}

int main() {
    loadFromFile();
    int choice;
    do {
        cout << "\n===== Student Management System =====\n"
             << "1. Student add karein\n"
             << "2. Sab students dekhein\n"
             << "3. Roll number se search karein\n"
             << "4. Marks update karein\n"
             << "5. Student delete karein\n"
             << "6. Marks ke hisab se sort karein\n"
             << "0. Save karke exit\n";
        choice = readInt("Apna choice: ");
        switch (choice) {
            case 1: addStudent(); break;
            case 2: displayAll(); break;
            case 3: searchStudent(); break;
            case 4: updateMarks(); break;
            case 5: deleteStudent(); break;
            case 6: sortByMarks(); break;
            case 0: saveToFile(); cout << "Data save ho gaya. Khuda hafiz!\n"; break;
            default: cout << "Galat choice.\n";
        }
    } while (choice != 0);
    freeList();
    return 0;
}
